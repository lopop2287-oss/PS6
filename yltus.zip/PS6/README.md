# PS6 — оболочка в стиле PlayStation для Android (Kotlin + Jetpack Compose)

## Сборка APK
1. Android Studio (Koala/Ladybug или новее, JDK 17) → File ▸ Open → папка `PS6`.
2. Дождаться Gradle Sync (Studio сам скачает Gradle wrapper и зависимости).
3. Build ▸ Build APK(s) → `app/build/outputs/apk/debug/app-debug.apk`.
   Из консоли: `gradle wrapper && ./gradlew assembleDebug`.
4. Установить: `adb install app/build/outputs/apk/debug/app-debug.apk`.
5. Сделать основным экраном: Настройки PS6 ▸ «Сделать PS6 основным экраном».
