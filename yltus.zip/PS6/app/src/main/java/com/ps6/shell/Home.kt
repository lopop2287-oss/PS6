@file:OptIn(ExperimentalFoundationApi::class)

package com.ps6.shell

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(vm: Ps6Vm, p: Profile, go: (Screen) -> Unit, onControl: () -> Unit) {
    val ctx = LocalContext.current
    val pr = LocalPrefs.current
    val hap = LocalHapticFeedback.current
    val list = p.apps.mapNotNull { vm.apps[it] }.filter { if (vm.tab == 0) it.isGame else !it.isGame }
    var sel by remember { mutableIntStateOf(0) }
    val selIdx = sel.coerceIn(0, maxOf(0, list.lastIndex))
    val cur = list.getOrNull(selIdx)
    var menu by remember { mutableStateOf<AppInfo?>(null) }
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(vm.tab) { sel = 0 }
    // фон подстраивается под выбранную игру
    LaunchedEffect(cur?.pkg) {
        vm.tint = cur?.let { Color.hsv(((it.pkg.hashCode() and 0x7fffffff) % 360).toFloat(), 0.7f, 0.9f) } ?: Color.Transparent
    }
    // первый фокус для управления геймпадом
    LaunchedEffect(Unit) { delay(500); runCatching { firstFocus.requestFocus() } }

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 6.dp)) {
        // ---------- верхняя панель
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TabLabel("Игры", vm.tab == 0) { vm.tab = 0 }
            TabLabel("Медиа", vm.tab == 1) { vm.tab = 1 }
            Spacer(Modifier.weight(1f))
            StatusInfo()
            Spacer(Modifier.width(14.dp))
            RoundBtn("🛒") { go(Screen.Store) }
            Spacer(Modifier.width(8.dp))
            RoundBtn("🎛") { onControl() }
            Spacer(Modifier.width(10.dp))
            Row(
                Modifier.glass(RoundedCornerShape(50), 0.12f).clickable { Sfx.ok(); go(Screen.Profile) }.padding(start = 4.dp, end = 14.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Avatar(p, 34.dp)
                Spacer(Modifier.width(8.dp))
                Text(p.nick, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }

        // ---------- лента / сетка приложений
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val base = minOf(120.dp, maxHeight * 0.5f) * pr.iconScale
            if (list.isEmpty()) {
                Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                    Text("Здесь пока пусто", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Откройте PlayStation Store и добавьте приложения", color = Color.White.copy(alpha = 0.7f))
                    Spacer(Modifier.height(14.dp))
                    PsButton("🛒  PlayStation Store", primary = true) { go(Screen.Store) }
                }
            } else if (!pr.grid) {
                val ls = rememberLazyListState()
                LaunchedEffect(selIdx, list.size) { ls.animateScrollToItem(selIdx) }
                LazyRow(
                    Modifier.fillMaxSize(), ls,
                    contentPadding = PaddingValues(horizontal = maxOf(0.dp, (maxWidth - base) / 2), vertical = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    itemsIndexed(list, key = { _, a -> a.pkg }) { i, a ->
                        AppTile(
                            a, base, i == selIdx, if (i == 0) Modifier.focusRequester(firstFocus) else Modifier,
                            { sel = i }, { vm.launch(ctx, a.pkg) }, { menu = a },
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    GridCells.Adaptive(base + 24.dp), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    itemsIndexed(list, key = { _, a -> a.pkg }) { i, a ->
                        Box(Modifier.fillMaxWidth(), Alignment.Center) {
                            AppTile(
                                a, base * 0.8f, i == selIdx, if (i == 0) Modifier.focusRequester(firstFocus) else Modifier,
                                { sel = i }, { vm.launch(ctx, a.pkg) }, { menu = a },
                            )
                        }
                    }
                }
            }
        }

        // ---------- название выбранного и быстрые действия
        Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(cur?.label ?: "PS6", fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (cur != null) Text("Время игры: ${fmtTime(p.playMs[cur.pkg] ?: 0L)}", fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f))
            }
            if (cur != null) {
                PsButton("✕  Играть", primary = true) { vm.launch(ctx, cur.pkg) }
                Spacer(Modifier.width(8.dp))
                PsButton(if (cur.pkg in p.favs) "★" else "☆") {
                    vm.update(p.copy(favs = if (cur.pkg in p.favs) p.favs - cur.pkg else p.favs + cur.pkg))
                }
                Spacer(Modifier.width(8.dp))
                PsButton("△  Меню") { menu = cur }
            }
        }

        // ---------- недавние / продолжить
        val rec = p.recent.mapNotNull { vm.apps[it] }
        if (rec.isNotEmpty()) {
            LazyRow(Modifier.fillMaxWidth().height(52.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                itemsIndexed(rec) { i, a ->
                    Row(
                        Modifier.glass(RoundedCornerShape(16.dp), 0.10f).clickable { Sfx.ok(); vm.launch(ctx, a.pkg) }.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Image(a.icon, null, Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)))
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(a.label, fontSize = 12.sp, maxLines = 1, fontWeight = FontWeight.SemiBold)
                            Text((if (i == 0) "Продолжить · " else "") + fmtTime(p.playMs[a.pkg] ?: 0L), fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }

    // ---------- долгое нажатие: убрать / порядок / избранное
    menu?.let { a ->
        fun swap(d: Int) {
            val i = list.indexOfFirst { it.pkg == a.pkg }
            val o = list.getOrNull(i + d) ?: return
            val l = p.apps.toMutableList()
            val x = l.indexOf(a.pkg); val y = l.indexOf(o.pkg)
            if (x < 0 || y < 0) return
            l[x] = o.pkg; l[y] = a.pkg
            vm.update(p.copy(apps = l)); sel = i + d
        }
        GlassDialog({ menu = null }) {
            Text(a.label, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            PsButton(if (a.pkg in p.favs) "☆  Убрать из избранного" else "★  В избранное") {
                vm.update(p.copy(favs = if (a.pkg in p.favs) p.favs - a.pkg else p.favs + a.pkg)); menu = null
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PsButton("◀  Влево") { swap(-1) }
                PsButton("Вправо  ▶") { swap(1) }
            }
            PsButton("🗑  Убрать из PS6") { vm.update(p.copy(apps = p.apps - a.pkg, favs = p.favs)); menu = null }
        }
    }
}

@Composable
private fun TabLabel(t: String, on: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(10.dp)).clickable { Sfx.move(); onClick() }.padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(t, fontSize = if (on) 20.sp else 17.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, color = Color.White.copy(alpha = if (on) 1f else 0.6f))
        Box(Modifier.height(3.dp).width(28.dp).clip(CircleShape).background(if (on) LocalTheme.current.accent else Color.Transparent))
    }
}

@Composable
private fun AppTile(
    a: AppInfo, base: Dp, selected: Boolean, modifier: Modifier,
    onSelect: () -> Unit, onOpen: () -> Unit, onLong: () -> Unit,
) {
    val th = LocalTheme.current
    val pr = LocalPrefs.current
    val hap = LocalHapticFeedback.current
    val sz by animateDpAsState(if (selected) base * 1.3f else base, spring(stiffness = Spring.StiffnessMediumLow), label = "sz")
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier.size(sz)
            .drawBehind {
                if (selected) drawCircle(Brush.radialGradient(listOf(th.accent.copy(alpha = 0.55f), Color.Transparent), center, this.size.minDimension * 0.95f))
            }
            .onFocusChanged { if (it.isFocused) onSelect() }
            .combinedClickable(
                onClick = {
                    if (selected) { Sfx.ok(); onOpen() }
                    else { Sfx.move(); if (pr.haptic) hap.performHapticFeedback(HapticFeedbackType.TextHandleMove); onSelect() }
                },
                onLongClick = { if (pr.haptic) hap.performHapticFeedback(HapticFeedbackType.LongPress); onLong() },
            )
            .clip(shape).background(Color.White.copy(alpha = 0.10f))
            .border(if (selected) 3.dp else 1.dp, if (selected) th.accent else Color.White.copy(alpha = 0.3f), shape),
        Alignment.Center,
    ) {
        Image(a.icon, a.label, Modifier.fillMaxSize().padding(sz / 9))
    }
}
