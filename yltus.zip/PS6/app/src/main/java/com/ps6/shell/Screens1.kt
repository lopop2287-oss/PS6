package com.ps6.shell

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

// ------------------------------------------------------------ анимация включения
@Composable
fun BootScreen(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { Sfx.boot() }
        a.animateTo(1f, tween(1800))
        delay(800)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "PS6", color = Color.White.copy(alpha = a.value), fontSize = (64 + 24 * a.value).sp,
                fontWeight = FontWeight.Black, letterSpacing = 8.sp,
                style = TextStyle(shadow = Shadow(Color(0xFFB388FF), blurRadius = 48f * a.value)),
            )
            Text("PlayStation 6", color = Color.White.copy(alpha = a.value * 0.6f), fontSize = 14.sp, letterSpacing = 4.sp)
        }
    }
}

// ------------------------------------------------------------ приветствие (первый запуск)
@Composable
fun WelcomeScreen(onCreate: () -> Unit, onGuest: () -> Unit) {
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Добро пожаловать в PS6", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Создайте профиль, чтобы сохранять трофеи и время игры", color = Color.White.copy(alpha = 0.7f))
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            PsButton("✕  Создать профиль", primary = true, onClick = onCreate)
            PsButton("Войти как гость", onClick = onGuest)
        }
    }
}

// ------------------------------------------------------------ выбор профиля
@Composable
fun SelectScreen(vm: Ps6Vm, onPick: (String) -> Unit, onAdd: () -> Unit, onGuest: () -> Unit) {
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Кто играет?", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(horizontal = 24.dp)) {
            items(vm.state.profiles, key = { it.id }) { p ->
                Tile({ onPick(p.id) }) {
                    Avatar(p, 92.dp)
                    Spacer(Modifier.height(8.dp))
                    Text(p.nick, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text("Ур. ${p.level()}", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                }
            }
            item {
                Tile(onAdd) {
                    Box(Modifier.size(92.dp).clip(CircleShape).border(2.dp, Color.White.copy(alpha = 0.5f), CircleShape), Alignment.Center) { Text("＋", fontSize = 36.sp) }
                    Spacer(Modifier.height(8.dp))
                    Text("Добавить профиль", fontSize = 13.sp)
                }
            }
            item {
                Tile(onGuest) {
                    Box(Modifier.size(92.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)), Alignment.Center) { Text("👤", fontSize = 36.sp) }
                    Spacer(Modifier.height(8.dp))
                    Text("Гость", fontSize = 13.sp)
                }
            }
        }
    }
}

// ------------------------------------------------------------ создание / редактирование профиля
@Composable
fun CreateScreen(vm: Ps6Vm, editing: Profile?, onBack: () -> Unit, onDone: () -> Unit) {
    val th = LocalTheme.current
    val id = remember { editing?.id ?: UUID.randomUUID().toString() }
    var nick by remember { mutableStateOf(editing?.nick ?: "") }
    var avatar by remember { mutableIntStateOf(editing?.avatar ?: 0) }
    var photo by remember { mutableStateOf(editing?.photo) }
    var frame by remember { mutableLongStateOf(editing?.frame ?: Palette[0]) }
    var accent by remember { mutableLongStateOf(editing?.accent ?: Palette[1]) }
    var touched by remember { mutableStateOf(false) }
    var creating by remember { mutableStateOf(false) }

    val n = nick.trim()
    val err = when {
        n.isEmpty() -> "Введите ник"
        n.length !in 3..16 -> "От 3 до 16 символов"
        vm.nickTaken(n, editing?.id) -> "Это имя уже занято"
        else -> null
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.savePhoto(uri, id)?.let { photo = it }
    }
    val preview = Profile(id, n.ifEmpty { "Ник" }, avatar, photo, frame, accent)

    LaunchedEffect(creating) {
        if (creating) {
            delay(1600)
            vm.addProfile(preview.copy(nick = n))
            onDone()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxSize().padding(20.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Column(Modifier.weight(1.2f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (editing == null) "Создать профиль" else "Изменить профиль", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = nick, onValueChange = { if (it.length <= 16) { nick = it; touched = true } },
                    label = { Text("Ник") }, singleLine = true, isError = touched && err != null,
                    supportingText = { Text(if (touched && err != null) err else "${n.length}/16") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Аватар", fontWeight = FontWeight.SemiBold)
                AvatarGlyphs.indices.chunked(6).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { i ->
                            Box(
                                Modifier.size(46.dp).clip(CircleShape).background(avatarBrush(i))
                                    .border(if (avatar == i && photo == null) 3.dp else 0.dp, Color.White, CircleShape)
                                    .clickable { avatar = i; photo = null; Sfx.move() },
                                Alignment.Center,
                            ) { Text(AvatarGlyphs[i], fontSize = 22.sp) }
                        }
                    }
                }
                PsButton("📷  Своё фото из галереи") { picker.launch("image/*") }
                Text("Цвет рамки", fontWeight = FontWeight.SemiBold)
                ColorRow(frame) { frame = it }
                Text("Цвет профиля", fontWeight = FontWeight.SemiBold)
                ColorRow(accent) { accent = it }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp)) {
                    PsButton("○  Назад", onClick = onBack)
                    PsButton("✕  Готово", primary = true) {
                        touched = true
                        if (err == null) {
                            if (editing != null) { vm.update(editing.copy(nick = n, avatar = avatar, photo = photo, frame = frame, accent = accent)); onDone() }
                            else creating = true
                        }
                    }
                }
            }
            // живой предпросмотр карточки профиля
            Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.Center, Alignment.CenterHorizontally) {
                Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), 0.16f).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(Color(accent)))
                    Spacer(Modifier.height(14.dp))
                    Avatar(preview, 110.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(preview.nick, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Уровень 1  ·  Трофеи 0/8", fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f))
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { 0.1f }, color = Color(accent), modifier = Modifier.fillMaxWidth())
                }
            }
        }
        if (creating) {
            Column(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.75f)), Arrangement.Center, Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = th.accent)
                Spacer(Modifier.height(16.dp))
                Text("Создаём профиль…", fontSize = 20.sp)
            }
        }
    }
}

@Composable
private fun ColorRow(selected: Long, onPick: (Long) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Palette.forEach { c ->
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                    .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Color.White else Color.White.copy(alpha = 0.3f), CircleShape)
                    .clickable { onPick(c); Sfx.move() },
            )
        }
    }
}
