package com.ps6.shell

import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------ настройки
@Composable
fun SettingsScreen(vm: Ps6Vm, p: Profile, onBack: () -> Unit, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val pr = LocalPrefs.current
    var confirmDelete by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RoundBtn("○") { onBack() }
            Text("Настройки", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Тема", fontWeight = FontWeight.SemiBold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Themes.forEachIndexed { i, t -> PsButton(t.name, primary = p.theme == i) { vm.update(p.copy(theme = i)) } }
            }
            SwitchRow("Звуки навигации", pr.sound) { vm.setPrefs(pr.copy(sound = it)) }
            SwitchRow("Вибрация при выборе", pr.haptic) { vm.setPrefs(pr.copy(haptic = it)) }
            SwitchRow("Анимации фона (волны, частицы)", pr.anim) { vm.setPrefs(pr.copy(anim = it)) }
            SwitchRow("Параллакс при наклоне телефона", pr.parallax) { vm.setPrefs(pr.copy(parallax = it)) }
            Text("Размер иконок", fontWeight = FontWeight.SemiBold)
            Slider(pr.iconScale, { vm.setPrefs(pr.copy(iconScale = it)) }, valueRange = 0.7f..1.3f, modifier = Modifier.widthIn(max = 360.dp))
            Text("Главный экран", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PsButton("Лента", primary = !pr.grid) { vm.setPrefs(pr.copy(grid = false)) }
                PsButton("Сетка", primary = pr.grid) { vm.setPrefs(pr.copy(grid = true)) }
            }
            Text("Профиль", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                if (vm.isGuest) {
                    PsButton("Создать профиль", primary = true) { vm.editing = null; go(Screen.Create) }
                } else {
                    PsButton("Изменить ник и аватар") { vm.editing = p; go(Screen.Create) }
                    PsButton("🗑 Удалить профиль") { confirmDelete = true }
                }
                PsButton("Сменить профиль") { go(Screen.Select) }
            }
            Text("Система", fontWeight = FontWeight.SemiBold)
            PsButton("Сделать PS6 основным экраном") {
                runCatching { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            Text("PS6 v1.0", fontSize = 12.sp, color = Color.White.copy(alpha = 0.4f))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Удалить профиль «${p.nick}»?") },
            text = { Text("Приложения, трофеи и время игры этого профиля будут удалены.") },
            confirmButton = { TextButton({ confirmDelete = false; vm.deleteProfile(p.id); go(Screen.Select) }) { Text("Удалить", color = Color(0xFFFF6B6B)) } },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun SwitchRow(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.widthIn(max = 460.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(v, onChange)
    }
}

// ------------------------------------------------------------ профиль: уровень, трофеи, недавние
@Composable
fun ProfileScreen(vm: Ps6Vm, p: Profile, onBack: () -> Unit, go: (Screen) -> Unit) {
    val th = LocalTheme.current
    val list = trophies(p)
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RoundBtn("○") { onBack() }
            Avatar(p, 54.dp)
            Column(Modifier.weight(1f)) {
                Text(p.nick, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Уровень ${p.level()}  ·  Трофеи ${list.count { it.ok }}/${list.size}", fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f))
                LinearProgressIndicator(progress = { p.levelProgress() }, color = Color(p.accent), modifier = Modifier.width(220.dp))
            }
            PsButton("⚙ Настройки") { go(Screen.Settings) }
        }
        if (vm.isGuest) {
            Text("Вы вошли как гость: профиль, трофеи и время игры не сохраняются.", color = Color.White.copy(alpha = 0.7f))
            PsButton("Создать профиль", primary = true) { vm.editing = null; go(Screen.Create) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Трофеи", fontWeight = FontWeight.SemiBold)
            list.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { t ->
                        Row(
                            Modifier.weight(1f).glass(RoundedCornerShape(16.dp), 0.10f).alpha(if (t.ok) 1f else 0.4f).padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(t.icon, fontSize = 26.sp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(t.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(t.desc, fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                            }
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Text("Недавно играл", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            val rec = p.recent.mapNotNull { vm.apps[it] }
            if (rec.isEmpty()) Text("Пока ничего", color = Color.White.copy(alpha = 0.5f))
            rec.forEach { a ->
                Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp), 0.08f).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.foundation.Image(a.icon, null, Modifier.size(32.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(a.label, Modifier.weight(1f), maxLines = 1)
                    Text(fmtTime(p.playMs[a.pkg] ?: 0L), fontSize = 13.sp, color = th.accent2)
                }
            }
        }
    }
}

// ------------------------------------------------------------ центр управления
@Composable
fun ControlCenter(vm: Ps6Vm, onDismiss: () -> Unit, onSwitch: () -> Unit, onCreate: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as? Activity
    val am = ctx.getSystemService(AudioManager::class.java)
    val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var br by remember {
        mutableFloatStateOf((act?.window?.attributes?.screenBrightness ?: -1f).let { if (it < 0f) 0.6f else it })
    }
    fun open(action: String) = runCatching { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    GlassDialog(onDismiss) {
        Text("Центр управления", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PsButton("📶 Wi-Fi") { open(Settings.ACTION_WIFI_SETTINGS) }
            PsButton("🔔 Уведомления") { open(Settings.ACTION_SETTINGS) }
        }
        Text("☀ Яркость", fontSize = 13.sp)
        Slider(br, {
            br = it
            act?.window?.let { w -> w.attributes = w.attributes.also { a -> a.screenBrightness = it } }
        }, valueRange = 0.05f..1f)
        Text("🔊 Громкость", fontSize = 13.sp)
        Slider(vol, { vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0) },
            valueRange = 0f..maxV.toFloat(), steps = (maxV - 1).coerceAtLeast(0))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (vm.isGuest) PsButton("Создать профиль", primary = true) { onDismiss(); onCreate() }
            PsButton("👤 Профили") { onDismiss(); onSwitch() }
        }
        PsButton("⏻  Закрыть PS6") { act?.finish() }
    }
}
