package com.ps6.shell

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

data class AppInfo(val pkg: String, val label: String, val icon: ImageBitmap, val isGame: Boolean)

enum class Screen { Boot, Welcome, Select, Create, Home, Store, Settings, Profile }

class Ps6Vm(app: Application) : AndroidViewModel(app) {
    var state by mutableStateOf(AppState()); private set
    var loaded by mutableStateOf(false); private set
    var currentId by mutableStateOf<String?>(null)
    var guest by mutableStateOf(Profile(GUEST, "Гость"))
    var apps by mutableStateOf<Map<String, AppInfo>>(emptyMap()); private set
    var tab by mutableIntStateOf(0)
    var tint by mutableStateOf(Color.Transparent)
    var editing by mutableStateOf<Profile?>(null)
    private var pending: Pair<String, Long>? = null

    init {
        viewModelScope.launch { state = Repo.load(getApplication()); loaded = true }
        refreshApps()
    }

    val current: Profile? get() = if (currentId == GUEST) guest else state.profiles.find { it.id == currentId }
    val isGuest: Boolean get() = currentId == GUEST

    private fun persist() { viewModelScope.launch { Repo.save(getApplication(), state) } }

    fun update(p: Profile) {
        if (p.id == GUEST) { guest = p; return }
        state = state.copy(profiles = state.profiles.map { if (it.id == p.id) p else it })
        persist()
    }

    fun setPrefs(p: Prefs) { state = state.copy(prefs = p); persist() }

    fun addProfile(p: Profile) {
        state = state.copy(profiles = state.profiles + p)
        currentId = p.id
        persist()
    }

    fun deleteProfile(id: String) {
        getApplication<Application>().filesDir.listFiles()?.filter { it.name.startsWith("avatar_$id") }?.forEach { it.delete() }
        state = state.copy(profiles = state.profiles.filter { it.id != id })
        if (currentId == id) currentId = null
        persist()
    }

    fun nickTaken(n: String, exceptId: String?): Boolean =
        n.equals("Гость", true) || state.profiles.any { it.id != exceptId && it.nick.equals(n, true) }

    /** Центр-кроп до квадрата, 512×512, в приватную папку приложения (отображается кругом). */
    fun savePhoto(uri: Uri, id: String): String? = runCatching {
        val ctx = getApplication<Application>()
        val bmp = ctx.contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) } ?: return null
        val s = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s)
        val out = Bitmap.createScaledBitmap(sq, 512, 512, true)
        ctx.filesDir.listFiles()?.filter { it.name.startsWith("avatar_$id") }?.forEach { it.delete() }
        val f = File(ctx.filesDir, "avatar_${id}_${System.currentTimeMillis()}.jpg")
        f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        f.absolutePath
    }.getOrNull()

    /** Все приложения с лаунчер-иконкой (нужно QUERY_ALL_PACKAGES). */
    fun refreshApps() {
        viewModelScope.launch(Dispatchers.Default) {
            val ctx = getApplication<Application>()
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(i, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .distinctBy { it.activityInfo.packageName }
                .map { r ->
                    val ai = r.activityInfo.applicationInfo
                    @Suppress("DEPRECATION")
                    val game = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                    AppInfo(
                        r.activityInfo.packageName, r.loadLabel(pm).toString(),
                        r.loadIcon(pm).toBitmap(160, 160).asImageBitmap(), game,
                    )
                }
                .sortedBy { it.label.lowercase() }
            apps = list.associateBy { it.pkg }
        }
    }

    fun launch(ctx: Context, pkg: String) {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val p = current ?: return
        val isGuest = p.id == GUEST
        if (!isGuest) pending = pkg to System.currentTimeMillis()
        update(p.copy(
            recent = (listOf(pkg) + p.recent.filter { it != pkg }).take(12),
            launches = p.launches + if (isGuest) 0 else 1,
        ))
        runCatching { ctx.startActivity(intent) }
    }

    /** Возврат из приложения: считаем время игры (гостю не считается). */
    fun onResume() {
        val (pkg, t) = pending ?: return
        pending = null
        val p = current ?: return
        val dt = System.currentTimeMillis() - t
        if (dt < 3000 || p.id == GUEST) return
        update(p.copy(playMs = p.playMs + (pkg to ((p.playMs[pkg] ?: 0L) + dt))))
    }
}
