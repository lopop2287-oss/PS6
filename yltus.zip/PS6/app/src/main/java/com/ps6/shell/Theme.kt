package com.ps6.shell

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

data class Ps6Theme(
    val name: String,
    val bg: List<Color>,
    val accent: Color,
    val accent2: Color,
)

val Themes = listOf(
    Ps6Theme("Фиолетовая ночь", listOf(Color(0xFF0B0420), Color(0xFF2A0A5E), Color(0xFF6C2BD9)), Color(0xFFFF4FD8), Color(0xFFB388FF)),
    Ps6Theme("Неон", listOf(Color(0xFF05010F), Color(0xFF1B0346), Color(0xFFB000FF)), Color(0xFF00F0FF), Color(0xFFFF2BD6)),
    Ps6Theme("Космос", listOf(Color(0xFF020212), Color(0xFF0A1040), Color(0xFF4A2BA8)), Color(0xFF7FDBFF), Color(0xFFC39BFF)),
    Ps6Theme("Стеклянный", listOf(Color(0xFF1A0B3B), Color(0xFF4B1FA8), Color(0xFF9B5CFF)), Color(0xFFFFFFFF), Color(0xFFE0C8FF)),
)

val LocalTheme = compositionLocalOf { Themes[0] }
val LocalPrefs = compositionLocalOf { Prefs() }

/** «Стеклянная» карточка: полупрозрачный градиент, световая кромка, тень. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(20.dp), alpha: Float = 0.12f): Modifier =
    this.shadow(8.dp, shape, clip = false)
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = alpha + 0.06f), Color.White.copy(alpha = alpha * 0.5f))))
        .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.45f), Color.White.copy(alpha = 0.05f))), shape)

/** Звуки навигации. Для настоящего звука PS положите файлы в res/raw и замените на SoundPool. */
object Sfx {
    @Volatile var on = true
    private val tg: ToneGenerator? by lazy { runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 45) }.getOrNull() }
    fun move() { if (on) tg?.startTone(ToneGenerator.TONE_PROP_BEEP, 25) }
    fun ok() { if (on) tg?.startTone(ToneGenerator.TONE_PROP_ACK, 80) }
    suspend fun boot() {
        if (!on) return
        for (t in listOf(ToneGenerator.TONE_DTMF_1, ToneGenerator.TONE_DTMF_5, ToneGenerator.TONE_DTMF_9)) {
            tg?.startTone(t, 160); delay(200)
        }
    }
}
