package com.ps6.shell

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun StoreScreen(vm: Ps6Vm, p: Profile, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val th = LocalTheme.current
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<AppInfo?>(null) }
    var downloading by remember { mutableStateOf<AppInfo?>(null) }
    val cats = listOf("Игры", "Приложения", "Недавние", "Избранное")

    val items = vm.apps.values.filter {
        it.label.contains(q.trim(), ignoreCase = true) && when (cat) {
            0 -> it.isGame
            1 -> !it.isGame
            2 -> it.pkg in p.recent
            else -> it.pkg in p.favs
        }
    }.let { l -> if (cat == 2) l.sortedBy { p.recent.indexOf(it.pkg) } else l }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RoundBtn("○") { onBack() }
            Text("PlayStation Store", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            OutlinedTextField(
                q, { q = it }, singleLine = true, placeholder = { Text("🔍 Поиск") },
                modifier = Modifier.width(240.dp), shape = RoundedCornerShape(50),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            cats.forEachIndexed { i, c -> PsButton(c, primary = cat == i) { cat = i } }
        }
        when {
            vm.apps.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = th.accent) }
            items.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Ничего не найдено", color = Color.White.copy(alpha = 0.6f)) }
            else -> LazyVerticalGrid(
                GridCells.Adaptive(108.dp), Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(items, key = { it.pkg }) { a ->
                    Tile({ sel = a }, Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.10f)) {
                        Box {
                            Image(a.icon, a.label, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
                            if (a.pkg in p.apps) Text("✓", color = th.accent, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.TopEnd))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(a.label, fontSize = 12.sp, maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }

    // карточка приложения
    sel?.let { a ->
        val added = a.pkg in p.apps
        GlassDialog({ sel = null }) {
            Image(a.icon, a.label, Modifier.size(84.dp).clip(RoundedCornerShape(20.dp)))
            Text(a.label, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(a.pkg, fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
            if (added) PsButton("🗑  Убрать из PS6") { vm.update(p.copy(apps = p.apps - a.pkg)); sel = null }
            else PsButton("✕  Добавить в PS6", primary = true) { downloading = a; sel = null }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PsButton(if (a.pkg in p.favs) "★ В избранном" else "☆ В избранное") {
                    vm.update(p.copy(favs = if (a.pkg in p.favs) p.favs - a.pkg else p.favs + a.pkg))
                }
                PsButton("▶ Открыть") { vm.launch(ctx, a.pkg) }
            }
        }
    }

    // «загрузка» как в PS5
    downloading?.let { a ->
        val prog = remember(a.pkg) { Animatable(0f) }
        LaunchedEffect(a.pkg) {
            prog.animateTo(1f, tween(1800, easing = LinearEasing))
            delay(350)
            vm.update(p.copy(apps = if (a.pkg in p.apps) p.apps else p.apps + a.pkg))
            downloading = null
        }
        GlassDialog({ }) {
            Image(a.icon, null, Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)))
            Text(if (prog.value >= 1f) "Готово ✓" else "Загрузка… ${(prog.value * 100).toInt()}%", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            LinearProgressIndicator(progress = { prog.value }, color = th.accent, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)))
            Text(a.label, fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
        }
    }
}
