package com.ps6.shell

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

const val GUEST = "guest"

data class Profile(
    val id: String,
    val nick: String,
    val avatar: Int = 0,
    val photo: String? = null,
    val frame: Long = 0xFFB388FF,
    val accent: Long = 0xFFFF4FD8,
    val theme: Int = 0,
    val apps: List<String> = emptyList(),
    val favs: List<String> = emptyList(),
    val recent: List<String> = emptyList(),
    val playMs: Map<String, Long> = emptyMap(),
    val launches: Int = 0,
)

data class Prefs(
    val sound: Boolean = true,
    val haptic: Boolean = true,
    val anim: Boolean = true,
    val parallax: Boolean = true,
    val iconScale: Float = 1f,
    val grid: Boolean = false,
)

data class AppState(val profiles: List<Profile> = emptyList(), val prefs: Prefs = Prefs())

// ---------- уровень и трофеи ----------
fun Profile.xp(): Long = launches * 10L + playMs.values.sum() / 60000
fun Profile.level(): Int = 1 + (xp() / 50).toInt()
fun Profile.levelProgress(): Float = (xp() % 50) / 50f

data class Trophy(val icon: String, val name: String, val desc: String, val tier: String, val ok: Boolean)

fun trophies(p: Profile): List<Trophy> {
    val total = p.playMs.values.sum()
    val base = listOf(
        Trophy("🥉", "Первый шаг", "Добавьте приложение в PS6", "Бронза", p.apps.isNotEmpty()),
        Trophy("🥈", "Коллекционер", "5 приложений в PS6", "Серебро", p.apps.size >= 5),
        Trophy("🥇", "Библиотека", "10 приложений в PS6", "Золото", p.apps.size >= 10),
        Trophy("🥉", "Игрок", "10 минут в приложениях", "Бронза", total >= 600_000),
        Trophy("🥈", "Марафонец", "1 час в приложениях", "Серебро", total >= 3_600_000),
        Trophy("🥇", "Ночной геймер", "5 часов в приложениях", "Золото", total >= 18_000_000),
        Trophy("⭐", "Фаворит", "Добавьте приложение в избранное", "Бронза", p.favs.isNotEmpty()),
    )
    return base + Trophy("💎", "Платина", "Получите все трофеи", "Платина", base.all { it.ok })
}

fun fmtTime(ms: Long): String {
    val m = ms / 60000
    return when {
        m < 1 -> "меньше минуты"
        m < 60 -> "$m мин"
        else -> "${m / 60} ч ${m % 60} мин"
    }
}

// ---------- JSON ----------
private fun JSONArray?.strings(): List<String> =
    if (this == null) emptyList() else (0 until length()).map { getString(it) }

fun Profile.toJson(): JSONObject = JSONObject().apply {
    put("id", id); put("nick", nick); put("avatar", avatar); put("photo", photo ?: "")
    put("frame", frame); put("accent", accent); put("theme", theme); put("launches", launches)
    put("apps", JSONArray(apps)); put("favs", JSONArray(favs)); put("recent", JSONArray(recent))
    put("play", JSONObject().also { o -> playMs.forEach { (k, v) -> o.put(k, v) } })
}

fun JSONObject.toProfile(): Profile {
    val pm = mutableMapOf<String, Long>()
    optJSONObject("play")?.let { o -> o.keys().forEach { k -> pm[k] = o.getLong(k) } }
    return Profile(
        id = getString("id"), nick = getString("nick"), avatar = optInt("avatar"),
        photo = optString("photo").ifEmpty { null },
        frame = optLong("frame", 0xFFB388FF), accent = optLong("accent", 0xFFFF4FD8),
        theme = optInt("theme"), launches = optInt("launches"),
        apps = optJSONArray("apps").strings(), favs = optJSONArray("favs").strings(),
        recent = optJSONArray("recent").strings(), playMs = pm,
    )
}

fun AppState.toJson(): JSONObject = JSONObject().apply {
    put("profiles", JSONArray().also { a -> profiles.forEach { a.put(it.toJson()) } })
    put("s", JSONObject().apply {
        put("sound", prefs.sound); put("haptic", prefs.haptic); put("anim", prefs.anim)
        put("parallax", prefs.parallax); put("scale", prefs.iconScale.toDouble()); put("grid", prefs.grid)
    })
}

fun parseState(text: String?): AppState {
    if (text == null) return AppState()
    return runCatching {
        val o = JSONObject(text)
        val arr = o.getJSONArray("profiles")
        val ps = (0 until arr.length()).map { arr.getJSONObject(it).toProfile() }
        val s = o.optJSONObject("s")
        val prefs = if (s == null) Prefs() else Prefs(
            s.optBoolean("sound", true), s.optBoolean("haptic", true), s.optBoolean("anim", true),
            s.optBoolean("parallax", true), s.optDouble("scale", 1.0).toFloat(), s.optBoolean("grid", false),
        )
        AppState(ps, prefs)
    }.getOrDefault(AppState())
}

// ---------- DataStore ----------
private val Context.store by preferencesDataStore("ps6")
private val KEY = stringPreferencesKey("state")

object Repo {
    suspend fun load(c: Context): AppState = parseState(c.store.data.first()[KEY])
    suspend fun save(c: Context, s: AppState) {
        c.store.edit { it[KEY] = s.toJson().toString() }
    }
}
