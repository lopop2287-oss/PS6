package com.ps6.shell

import android.app.ActivityManager
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    private val vm by viewModels<Ps6Vm>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent { Ps6App(vm) }
    }

    override fun onResume() {
        super.onResume()
        vm.onResume()
        vm.refreshApps() // подхватить новые/удалённые приложения
    }

    /** Геймпад: A → ✕ (выбор), B → ○ (назад), L1/R1 → вкладки «Игры»/«Медиа». Крестовина работает как фокус. */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val mapped = when (e.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_DPAD_CENTER
            KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BACK
            KeyEvent.KEYCODE_BUTTON_L1 -> { if (e.action == KeyEvent.ACTION_DOWN) vm.tab = 0; return true }
            KeyEvent.KEYCODE_BUTTON_R1 -> { if (e.action == KeyEvent.ACTION_DOWN) vm.tab = 1; return true }
            else -> return super.dispatchKeyEvent(e)
        }
        return super.dispatchKeyEvent(KeyEvent(e.action, mapped))
    }
}

@Composable
fun Ps6App(vm: Ps6Vm) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.Boot) }
    var control by remember { mutableStateOf(false) }
    val prefs = vm.state.prefs
    val p = vm.current
    val theme = Themes[(p?.theme ?: 0).coerceIn(0, Themes.lastIndex)]
    val tilt = rememberTilt(prefs.parallax)
    val low = remember {
        ctx.getSystemService(ActivityManager::class.java).isLowRamDevice || Runtime.getRuntime().availableProcessors() <= 4
    }

    LaunchedEffect(prefs.sound) { Sfx.on = prefs.sound }
    LaunchedEffect(screen) { if (screen != Screen.Home) vm.tint = Color.Transparent }
    // если профиль потерян (например, после удаления) — вернуться к выбору
    LaunchedEffect(p, screen) {
        if (p == null && screen in listOf(Screen.Home, Screen.Store, Screen.Settings, Screen.Profile)) screen = Screen.Select
    }

    BackHandler(enabled = screen != Screen.Boot) {
        when (screen) {
            Screen.Store, Screen.Settings, Screen.Profile -> screen = Screen.Home
            Screen.Create -> screen = if (vm.editing != null) Screen.Settings else if (vm.state.profiles.isEmpty() && !vm.isGuest) Screen.Welcome else if (vm.isGuest) Screen.Profile else Screen.Select
            Screen.Select -> if (vm.current != null) screen = Screen.Home
            else -> {}
        }
    }

    CompositionLocalProvider(LocalTheme provides theme, LocalPrefs provides prefs, LocalContentColor provides Color.White) {
        MaterialTheme(colorScheme = darkColorScheme(primary = theme.accent, secondary = theme.accent2, surface = Color(0xFF1A0B3B), onSurface = Color.White)) {
            Box(Modifier.fillMaxSize()) {
                Background(theme, vm.tint, prefs.anim, tilt, low)
                if (!vm.loaded) return@Box
                Box(Modifier.fillMaxSize().displayCutoutPadding()) {
                    Crossfade(screen, label = "screen") { sc ->
                        when (sc) {
                            Screen.Boot -> BootScreen { screen = if (vm.state.profiles.isEmpty()) Screen.Welcome else Screen.Select }
                            Screen.Welcome -> WelcomeScreen(
                                onCreate = { vm.editing = null; screen = Screen.Create },
                                onGuest = { vm.currentId = GUEST; vm.tab = 0; screen = Screen.Home },
                            )
                            Screen.Select -> SelectScreen(
                                vm,
                                onPick = { vm.currentId = it; vm.tab = 0; screen = Screen.Home },
                                onAdd = { vm.editing = null; screen = Screen.Create },
                                onGuest = { vm.currentId = GUEST; vm.tab = 0; screen = Screen.Home },
                            )
                            Screen.Create -> CreateScreen(
                                vm, vm.editing,
                                onBack = {
                                    screen = if (vm.editing != null) Screen.Settings
                                    else if (vm.state.profiles.isEmpty()) Screen.Welcome else Screen.Select
                                },
                                onDone = { val ed = vm.editing; vm.editing = null; vm.tab = 0; screen = if (ed != null) Screen.Settings else Screen.Home },
                            )
                            Screen.Home -> vm.current?.let { HomeScreen(vm, it, { s -> screen = s }, { control = true }) }
                            Screen.Store -> vm.current?.let { StoreScreen(vm, it) { screen = Screen.Home } }
                            Screen.Settings -> vm.current?.let { SettingsScreen(vm, it, { screen = Screen.Home }) { s -> screen = s } }
                            Screen.Profile -> vm.current?.let { ProfileScreen(vm, it, { screen = Screen.Home }) { s -> screen = s } }
                        }
                    }
                }
                if (control) ControlCenter(vm, { control = false }, { screen = Screen.Select }, { vm.editing = null; screen = Screen.Create })
            }
        }
    }
}
