package com.ps6.shell

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.PI
import kotlin.math.sin

// ------------------------------------------------------------------ фон
@Composable
fun Background(theme: Ps6Theme, tint: Color, anim: Boolean, tilt: State<Offset>, low: Boolean) {
    val t: State<Float> = if (anim)
        rememberInfiniteTransition(label = "bg").animateFloat(0f, 1f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "t")
    else remember { mutableStateOf(0f) }
    val tc by animateColorAsState(tint, tween(800), label = "tint")
    val pts = remember(low) {
        val r = Random(7)
        List(if (low) 16 else 44) { floatArrayOf(r.nextFloat(), r.nextFloat(), 1.5f + r.nextFloat() * 3f, (1 + r.nextInt(3)).toFloat()) }
    }
    val twoPi = (2 * PI).toFloat()
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val tv = t.value
        val tl = tilt.value
        drawRect(Brush.linearGradient(theme.bg, Offset.Zero, Offset(w, h)))
        // свечение в цвет выбранной игры
        drawRect(Brush.radialGradient(listOf(tc.copy(alpha = 0.40f), Color.Transparent), Offset(w * 0.72f + tl.x * 60f, h * 0.35f + tl.y * 40f), maxOf(w, h) * 0.65f))
        // медленные волны
        for (k in 0 until (if (low) 2 else 3)) {
            val path = Path()
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w + 28f) {
                val y = h * (0.66f + 0.09f * k) +
                    sin(x / w * twoPi * (1.1f + 0.35f * k) + tv * twoPi * (k + 1)) * h * 0.035f + tl.y * 10f * (k + 1)
                path.lineTo(x, y)
                x += if (low) 28f else 16f
            }
            path.lineTo(w, h)
            path.close()
            drawPath(path, theme.accent2.copy(alpha = 0.06f + 0.035f * k))
        }
        // частицы
        for (p in pts) {
            var yy = (p[1] - tv * p[3]) % 1f
            if (yy < 0f) yy += 1f
            drawCircle(Color.White.copy(alpha = 0.22f), p[2], Offset(p[0] * w + tl.x * 25f * p[2], yy * h))
        }
    }
}

/** Наклон телефона → смещение для параллакса. */
@Composable
fun rememberTilt(enabled: Boolean): State<Offset> {
    val ctx = LocalContext.current
    val st = remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(enabled) {
        if (!enabled) {
            st.value = Offset.Zero
            return@DisposableEffect onDispose { }
        }
        val sm = ctx.getSystemService(SensorManager::class.java)
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val tx = (e.values[1] / 9.8f).coerceIn(-1f, 1f)
                val ty = (e.values[0] / 9.8f).coerceIn(-1f, 1f)
                val c = st.value
                st.value = Offset(c.x + (tx - c.x) * 0.1f, c.y + (ty - c.y) * 0.1f)
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sm != null && sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm?.unregisterListener(l) }
    }
    return st
}

// ------------------------------------------------------------------ аватары
val AvatarGlyphs = listOf("✕", "○", "△", "□", "🚀", "🪐", "👾", "🤖", "🦊", "🐼", "⚡", "🌌")
private val AvatarColors = listOf(Color(0xFF3D7BFF), Color(0xFFFF4F6D), Color(0xFF2ED3A0), Color(0xFFFF6BD6), Color(0xFF7B3DFF), Color(0xFFFFB02E))
val Palette = listOf(0xFFB388FF, 0xFFFF4FD8, 0xFF00F0FF, 0xFF7CFFB2, 0xFFFFD166, 0xFFFF6B6B, 0xFF4D8DFF, 0xFFFFFFFF)

fun avatarBrush(i: Int) = Brush.linearGradient(listOf(AvatarColors[i % AvatarColors.size], AvatarColors[(i + 2) % AvatarColors.size]))

@Composable
fun Avatar(p: Profile, size: Dp, modifier: Modifier = Modifier) {
    val bmp = remember(p.photo) { p.photo?.let { runCatching { BitmapFactory.decodeFile(it)?.asImageBitmapSafe() }.getOrNull() } }
    val ring = maxOf(2.dp, size / 24)
    Box(
        modifier.size(size).border(ring, Color(p.frame), CircleShape).padding(ring + 1.dp)
            .clip(CircleShape).background(avatarBrush(p.avatar)),
        Alignment.Center,
    ) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(AvatarGlyphs[p.avatar.coerceIn(0, AvatarGlyphs.lastIndex)], fontSize = (size.value * 0.42f).sp, color = Color.White)
    }
}

private fun android.graphics.Bitmap.asImageBitmapSafe() = androidx.compose.ui.graphics.asImageBitmap(this)

// ------------------------------------------------------------------ кнопки и плитки
@Composable
fun PsButton(text: String, modifier: Modifier = Modifier, primary: Boolean = false, onClick: () -> Unit) {
    val th = LocalTheme.current
    val pr = LocalPrefs.current
    val hap = LocalHapticFeedback.current
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val sc by animateFloatAsState(if (focused) 1.08f else 1f, label = "btn")
    val shape = RoundedCornerShape(50)
    Box(
        modifier.scale(sc).glass(shape, if (primary) 0.30f else 0.12f)
            .then(if (focused) Modifier.border(2.dp, th.accent, shape) else Modifier)
            .clickable(interactionSource = src, indication = null) {
                Sfx.ok()
                if (pr.haptic) hap.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            }
            .padding(horizontal = 20.dp, vertical = 11.dp),
        Alignment.Center,
    ) { Text(text, fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
fun RoundBtn(text: String, onClick: () -> Unit) {
    val th = LocalTheme.current
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val sc by animateFloatAsState(if (focused) 1.15f else 1f, label = "rb")
    Box(
        Modifier.size(42.dp).scale(sc).glass(CircleShape, 0.18f)
            .then(if (focused) Modifier.border(2.dp, th.accent, CircleShape) else Modifier)
            .clickable(interactionSource = src, indication = null) { Sfx.ok(); onClick() },
        Alignment.Center,
    ) { Text(text, fontSize = 18.sp) }
}

@Composable
fun Tile(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val th = LocalTheme.current
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val sc by animateFloatAsState(if (focused) 1.08f else 1f, label = "tile")
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.scale(sc).clip(shape)
            .then(if (focused) Modifier.border(2.dp, th.accent, shape) else Modifier)
            .clickable(interactionSource = src, indication = null) { Sfx.ok(); onClick() }
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally, content = content,
    )
}

@Composable
fun GlassDialog(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        val shape = RoundedCornerShape(26.dp)
        Column(
            Modifier.widthIn(max = 460.dp).clip(shape).background(Color(0xF01A0B3B))
                .border(1.dp, Color.White.copy(alpha = 0.25f), shape)
                .verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp), content = content,
        )
    }
}

// ------------------------------------------------------------------ статус-бар (время, Wi-Fi, батарея)
@Composable
fun rememberBattery(): Int {
    val ctx = LocalContext.current
    var v by remember { mutableIntStateOf(100) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (s > 0) v = l * 100 / s
            }
        }
        ctx.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { r.onReceive(ctx, it) }
        onDispose { ctx.unregisterReceiver(r) }
    }
    return v
}

@Composable
fun StatusInfo() {
    val ctx = LocalContext.current
    val bat = rememberBattery()
    var time by remember { mutableStateOf("") }
    var wifi by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val f = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            time = f.format(Date())
            wifi = runCatching { cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }.getOrDefault(false)
            delay(15000)
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (wifi) "📶" else "📵", fontSize = 14.sp)
        Text("🔋$bat%", fontSize = 14.sp)
        Text(time, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}
